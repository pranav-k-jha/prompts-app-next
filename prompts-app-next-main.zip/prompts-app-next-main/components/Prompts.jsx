import React from 'react'

const Prompts = () => {
  return (
    <div>Prompts</div>
  )
}

export default Prompts